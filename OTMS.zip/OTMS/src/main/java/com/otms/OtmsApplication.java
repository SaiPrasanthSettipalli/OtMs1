package com.otms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtmsApplication.class, args);
	}

}
