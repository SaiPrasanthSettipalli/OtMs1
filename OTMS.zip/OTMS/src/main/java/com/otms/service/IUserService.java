package com.otms.service;

import com.otms.entity.User;

public interface IUserService {
	String registerUser(User user);
	User checkLoginDetails(String userEmail, String password);
}
